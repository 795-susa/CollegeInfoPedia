<!DOCTYPE html>
<html>
<?php include('dbconnect.php')?>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>COLLEGE INFOPEDIA</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Lobster+Two:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--Animation-->
<script src="js/wow.min.js"></script>
<link href="css/animate.css" rel='stylesheet' type='text/css' />
<script>
	new WOW().init();
</script>
<script src="js/simpleCart.min.js"> </script>	
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
</head>
<body>



<body>
    <!-- header-section-starts -->
	<div class="header">
		<div class="container">
			<div class="top-header">
				<div class="logo">
                    <div class="line" style="padding:0px !important;margin:0px!important">
                        <h2 style="color:#6a3e33">College Infopedia</h2>
                    </div>                    
				</div>
                <div class="header-right queries">
					<p>Questions? Call us Toll-free!<span>1800-0000-7777 </span><label>(11AM to 11PM)</label></p>
				</div>
				
				<div class="clearfix"></div>
			</div>
		</div>
		<!---728x90--->

			<div class="menu-bar">
			<div class="container">
				<div class="top-menu" style="margin:0px!important">
					<ul>
                        <li class="active"><a href="index.php" class="scroll" style="color:#6a3e33">Home</a></li>|						
						<div class="clearfix"></div>
					</ul>
				</div>
				<div class="login-section">
					<ul>
                        <?php 
                            session_start();
                            if(empty($_SESSION['user'])){
                                ?>
                        <li><a href="register.php" class="btn btn-primary" style="color:white">Register</a>  </li> |			
                        <li><a href="login.php" class="btn btn-primary" style="color:white">Login</a>  </li> |			

                                <?php
                            }
                            else{
                                ?>
                        <li><a href="logout.php" class="btn btn-primary" style="color:white">Logout</a>  </li> |		   
                                <?php
                            }                            
                        ?>				
						<div class="clearfix"></div>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="banner wow fadeInUp" data-wow-delay="0.4s" id="Home">
		    <div class="container">
				<div class="banner-info">
					<div class="banner-info-head text-center wow fadeInLeft" data-wow-delay="0.5s">
						<h1>College Infopedia</h1>
						<div class="line">
                            <h2>Search Colleges Based on Course & Places</h2>
						</div>
					</div>
					<div class="form-list wow fadeInRight" data-wow-delay="0.5s">
                        <div class="container">
                           <form name="f1" method="post" action="search_result.php">
                            <div class="row">
                               <div class="form-group col-md-1"></div>
                                <div class="form-group col-md-4">                                    
                                    <?php 
                                    $sql="SELECT * FROM course_category";
                                    $res=mysqli_query($link,$sql);                
                                    ?>
                                    <select name="course" id="course" class="form-control" required>
                                        <option value="">---SELECT COURSE---</option>
                                        <?php 
                                        while($row=mysqli_fetch_array($res)){
                                        ?>
                                        <option value="<?php echo $row['course_id'];?>"><?php echo $row['course_name'];?></option>
                                        <?php }?>
                                    </select>                        

                                </div>

                                <div class="form-group col-md-4">                                    
                                    <?php 
                                    $sql="SELECT * FROM cities";
                                    $res=mysqli_query($link,$sql);                
                                    ?>
                                    <select name="city" id="city" class="form-control" required>
                                        <option value="">SELECT CITY</option>
                                        <?php 
                                        while($row=mysqli_fetch_array($res)){
                                        ?>
                                        <option value="<?php echo $row['city_id'];?>"><?php echo $row['city_name'];?></option>
                                        <?php }?>
                                    </select>                        
                                </div>
                                <div class="form-group col-md-2">
                                    <input type="submit" value="SEARCH" class="btn btn-success">
                                </div>
                            </div>
                        </form>
                        </div>
						</div>
					<!-- start search-->
		 
					
				</div>
			</div>
		</div>
	</div>
	<!-- header-section-ends -->
	<!---728x90--->

	<!-- content-section-starts -->
	<div class="container-fluid">				
		<!---728x90--->

		<div class="popular-restaurents" id="Popular-Restaurants">			
				<div class="col-sm-16 top-cuisines">
					<div class="top-cuisine-head">
						<h3>Latest Top 3 Records</h3>
					</div>
                    <div class="col-sm-2"></div>
					<?php 
                    $sql2="select * from college c,cities ct,course_category cc where c.course_id=cc.course_id and ct.city_id=c.city_id ORDER BY c.userid DESC LIMIT 3";   
                    $res2=mysqli_query($link,$sql2);
                    while($row2=mysqli_fetch_array($res2)){
                    ?>
						<div class="top-cuisine-grid wow bounceIn col-sm-2" data-wow-delay="0.4s">
				<a href="#"><img src="city/photos/<?php echo $row2['image'];?>" height="150px" width="250px" /> </a>     
                                <h2 style="color:black"><?php echo $row2['collegename']?></h2>                          
                                <p><?php echo $row2['address']?></p>
					    </div>
                    
				<?php }?>		
						
					
				</div>
			
		</div>
	</div>
	<!-- content-section-ends -->
	<!-- footer-section-starts -->
	<div class="footer">
		<div class="container">
			<p class="wow fadeInLeft" data-wow-delay="0.4s">&copy; 2018 College Infopedia. All rights  Reserved</p>
		</div>
	</div>
	<!-- footer-section-ends -->
	  <script type="text/javascript">
						$(document).ready(function() {
							
							$().UItoTop({ easingType: 'easeOutQuart' });
							
						});
					</script>
				<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

</body>
</body>
</html>