<?php 
include('dbconnect.php');

$email=$_POST['email'];
$userid=$_POST['colgid'];
$comments=$_POST['comments'];

$sql="insert into comments(email,userid,comments)values('$email','$userid','$comments')";
$res=mysqli_query($link,$sql);
?>
<script>
alert("Thank You");
history.back();
</script>