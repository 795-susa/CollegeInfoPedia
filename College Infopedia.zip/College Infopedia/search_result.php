<!DOCTYPE html>
<html>

    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <head>
        <title>College Infopedia</title>
        <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery.min.js"></script>
        <!-- Custom Theme files -->
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
        <!-- Custom Theme files -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!--webfont-->
        <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Lobster+Two:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
        <!--Animation-->
        <script src="js/wow.min.js"></script>
        <link href="css/animate.css" rel='stylesheet' type='text/css' />
        <script>
            new WOW().init();
        </script>
        <script src="js/simpleCart.min.js"> </script>	
        <script type="text/javascript" src="js/move-top.js"></script>
        <script type="text/javascript" src="js/easing.js"></script>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $(".scroll").click(function(event){		
                    event.preventDefault();
                    $('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
                });
            });
        </script>
    </head>
    <body>



        <body>
    <!-- header-section-starts -->
	<div class="header">
		<div class="container">
			<div class="top-header">
				<div class="logo">
                    <div class="line" style="padding:0px !important;margin:0px!important">
                        <h2 style="color:#6a3e33">College Infopedia</h2>
                    </div>                    
				</div>
                <div class="header-right queries">
					<p>Questions? Call us Toll-free!<span>1800-0000-7777 </span><label>(11AM to 11PM)</label></p>
				</div>				
				<div class="clearfix"></div>
			</div>
		</div>
		<!---728x90--->

			<div class="menu-bar">
			<div class="container">
				<div class="top-menu">
					<ul>
						<li><a href="index.php">Home</a></li>|						
						<div class="clearfix"></div>
					</ul>
				</div>
                <div class="login-section">
                    <ul>
                        <?php 
                        session_start();
                        if(empty($_SESSION['user'])){
                        ?>
                        <li><a href="register.php" class="btn btn-primary" style="color:white">Register</a>  </li> |			
                        <li><a href="login.php" class="btn btn-primary" style="color:white">Login</a>  </li> |			

                        <?php
                        }
                        else{
                        ?>
                        <li><a href="logout.php" class="btn btn-primary" style="color:white">Logout</a>  </li> |		   
                        <?php
                        }                            
                        ?>				
                        <div class="clearfix"></div>
                    </ul>
                </div>
				<div class="clearfix"></div>
			</div>
		</div>		
				</div>


	<!-- header-section-ends -->
	<!-- content-section-starts -->
	<div class="Popular-Restaurants-content">
		<div class="Popular-Restaurants-grids">
			<div class="container">
			
			<?php 
                include('dbconnect.php');
                $course_id=$_POST['course'];    
                $city_id=$_POST['city'];
                $sql="select * from college c,cities ct,course_category cc where c.course_id=cc.course_id and c.city_id=ct.city_id and c.city_id=$city_id and c.course_id=$course_id";
                $res=mysqli_query($link,$sql);
                $count=mysqli_num_rows($res);
                if($count <=0){
                ?>
                <script>
                    alert("No Records Found");
                    window.location="index.php";
                </script>
                <?php    
                }else{
                while($row=mysqli_fetch_array($res)){
            ?>
				<div class="Popular-Restaurants-grid wow fadeInRight col-sm-16" data-wow-delay="0.4s">
					<div class="col-md-3 restaurent-logo">
						<img src="city/photos/<?php echo $row['image']?>" alt="" width="255px" height="170px" style="border:1px solid black"/>
					</div>
					<div class="col-md-5 restaurent-title">
						<div class="logo-title">
                            <p style="font-weight:bold;font-size:25px;color:#6a3e33"><?php echo $row['collegename'];?></p>
						</div>						
							<p style="font-weight:bold;font-size:20px"><?php echo $row['email'];?></p>							
                        <p style="font-weight:bold;font-size:20px">Address : <?php echo $row['address'];?></p>					
                        <p style="font-weight:bold;font-size:20px">Grade &nbsp;&nbsp;&nbsp;&nbsp;: <?php echo $row['grade'];?></p>						
                        <p style="font-weight:bold;font-size:20px">City &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <?php echo $row['city_name'];?></p>					                    								
					</div>
					<div class="col-md-3 buy">				
						<a class="morebtn hvr-rectangle-in" href="college_details.php?id=<?php echo $row['userid'];?>">View More Details</a>
					</div>
					<div class="clearfix"></div>
				</div>
		<?php }}?>
			</div>
		</div>		
	</div>
            <div class="clearfix"></div>
	<!---728x90--->
            <!-- content-section-ends -->
            <!-- footer-section-starts -->
            <div class="footer">
                <div class="container">
                    <p class="wow fadeInLeft" data-wow-delay="0.4s">&copy; 2018 College Infopedia. All rights  Reserved</p>
                </div>
            </div>
            <!-- footer-section-ends -->
            <script type="text/javascript">
                $(document).ready(function() {

                    $().UItoTop({ easingType: 'easeOutQuart' });

                });
            </script>
            <a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

        </body>
    </body>
</html>