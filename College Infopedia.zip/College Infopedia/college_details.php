<!DOCTYPE html>
<html>
<?php 
    include('dbconnect.php');    
?>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <head>
        <title>College Infopedia</title>
        <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery.min.js"></script>
        <!-- Custom Theme files -->
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
        <!-- Custom Theme files -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!--webfont-->
        <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Lobster+Two:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
        <!--Animation-->
        <script src="js/wow.min.js"></script>
        <link href="css/animate.css" rel='stylesheet' type='text/css' />
        <script>
            new WOW().init();
        </script>
        <script src="js/simpleCart.min.js"> </script>	
        <script type="text/javascript" src="js/move-top.js"></script>
        <script type="text/javascript" src="js/easing.js"></script>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $(".scroll").click(function(event){		
                    event.preventDefault();
                    $('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
                });
            });
        </script>
    </head>
    <body>    
    <!-- header-section-starts -->
	<div class="header">
		<div class="container">
			<div class="top-header">
				<div class="logo">
                    <div class="line" style="padding:0px !important;margin:0px!important">
                        <h2 style="color:#6a3e33">College Infopedia</h2>
                    </div>                    
				</div>
                <div class="header-right queries">
					<p>Questions? Call us Toll-free!<span>1800-0000-7777 </span><label>(11AM to 11PM)</label></p>
				</div>				
				<div class="clearfix"></div>
			</div>
		</div>
		<!---728x90--->

			<div class="menu-bar">
			<div class="container">
				<div class="top-menu">
					<ul>
						<li><a href="index.php">Home</a></li>|						
						<div class="clearfix"></div>
					</ul>
				</div>
                <div class="login-section">
                    <ul>
                        <?php 
                        session_start();
                        if(empty($_SESSION['user'])){
                        ?>
                        <li><a href="register.php" class="btn btn-primary" style="color:white">Register</a>  </li> |			
                        <li><a href="login.php" class="btn btn-primary" style="color:white">Login</a>  </li> |			

                        <?php
                        }
                        else{
                        ?>
                        <li><a href="logout.php" class="btn btn-primary" style="color:white">Logout</a>  </li> |		   
                        <?php
                        }                            
                        ?>				
                        <div class="clearfix"></div>
                    </ul>
                </div>
				<div class="clearfix"></div>
			</div>
		</div>		
				</div>

	<!-- header-section-ends -->
	<!-- content-section-starts -->
	<div class="Popular-Restaurants-content">
		<div class="Popular-Restaurants-grids">
			<div class="container">
			
			<?php 
                include('dbconnect.php');
                $college_id=$_REQUEST['id'];                    
                $sql="select * from placement where college_id=$college_id";
                $res=mysqli_query($link,$sql);                
                $row=mysqli_fetch_array($res);
            ?>                
                <div class="col-md-6 restaurent-logo">
                    <p style="font-weight:bold;font-size:25px;color:#6a3e33">PLACEMENT INFORMATION</p>
                </div><br><hr>
                <div class="col-sm-16" style="margin-left:20px;">                
                    <p style="font-weight:bold;font-size:15px;color:#6a3e33">COMPANY VISITED :&nbsp; <?php echo $row['comp_visited'];?></p><br>
                    <p style="font-weight:bold;font-size:15px;color:#6a3e33">SELECTED &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp; <?php echo $row['stud_selected'];?></p><br>
                    <p style="font-weight:bold;font-size:15px;color:#6a3e33">YEAR &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp; <?php echo $row['year'];?></p> <br>            
                </div>
				

                <?php 
                include('dbconnect.php');
                $college_id=$_REQUEST['id'];                    
                $sql1="select * from library where college_id=$college_id";
                $res1=mysqli_query($link,$sql1);                
                $row1=mysqli_fetch_array($res1);
                ?>                
                <div class="col-md-6 restaurent-logo">
                    <p style="font-weight:bold;font-size:25px;color:#6a3e33">LIBRARY INFORMATION</p>
                </div><br><hr>
                <div class="col-sm-16" style="margin-left:20px;">                
                    <p style="font-weight:bold;font-size:15px;color:#6a3e33">DOMAIN &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp; <?php echo $row1['Domain'];?></p><br>
                    <p style="font-weight:bold;font-size:15px;color:#6a3e33">NO OF BOOKS &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp; <?php echo $row1['no_of_books'];?></p><br>
                    <p style="font-weight:bold;font-size:15px;color:#6a3e33">NO OF MAGAZINES :&nbsp; <?php echo $row1['no_of_mgzns'];?></p> <br>            
                </div>


                <?php 
                include('dbconnect.php');
                $college_id=$_REQUEST['id'];                    
                $sql11="select * from otherdetails where college_id=$college_id";
                $res11=mysqli_query($link,$sql11);                
                $row11=mysqli_fetch_array($res11);
                ?>                
                <div class="col-md-6 restaurent-logo">
                    <p style="font-weight:bold;font-size:25px;color:#6a3e33">OTHER FACILITIES</p>
                </div><br><hr>
                <div class="col-sm-16" style="margin-left:20px;">                
                    <p style="font-weight:bold;font-size:15px;color:#6a3e33">LABS &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp; <?php echo $row11['labs'];?></p><br>
                    <p style="font-weight:bold;font-size:15px;color:#6a3e33">WIFI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp; <?php echo $row11['wifi'];?></p><br>
                    <p style="font-weight:bold;font-size:15px;color:#6a3e33">GIRLS HOSTEL &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp; <?php echo $row11['g_hostel'];?></p> <br>            
                    <p style="font-weight:bold;font-size:15px;color:#6a3e33">BOYS HOSTEL &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp; <?php echo $row11['b_hostel'];?></p> <br>            
                    <p style="font-weight:bold;font-size:15px;color:#6a3e33">CANTEEN HOSTEL :&nbsp; <?php echo $row11['canteen'];?></p> <br>            
                </div>
					<div class="clearfix"></div>
<!--				<a href="index.php" class="btn btn-primary">CLICK HERE TO NAVIGATE TO HOME PAGE</a>-->
				<br>                             
               <?php               
                error_reporting(0);
                session_start();                
                if(empty($_SESSION['user'])){
                    $id=$_REQUEST['id'];                    
                    ?>
                    <form name="f1" method="post" action="login.php">
                    <input type="hidden" name="college_id" value="<?php echo $id?>">
                    <input type="submit" class="btn btn-primary" value="Click Here to Comment">
                    </form>
                    <?php
                }else{
                ?>
                <div class="container">
                    <h2>Post Your Comments</h2>
                    <div class="row">
                       <form name="f1" method="post" action="comments_insert.php">
                        <div class="form-group col-md-4"> 
                        <?php
                    include('dbconnect.php');
                    $name=$_SESSION['user'];
                    $sql5="SELECT * FROM user where UserName='$name'";
                    $res5=mysqli_query($link,$sql5);                
                    $row5=mysqli_fetch_array($res5);                                                
                        ?>
                            <input type="text" readonly class="form-control" id="email" name="email" placeholder="Enter username" value="<?php echo $row5['Email'];?>">
                        </div>

                        <div class="form-group col-md-4">
                            <?php 
                            $id=$_REQUEST['id'];
                            $sql="SELECT * FROM college where userid=$id";
                            $res=mysqli_query($link,$sql);                
                            $row=mysqli_fetch_array($res);                                                
                            ?>
                            <input type="hidden" name="colgid" id="" value="<?php echo $id?>">
                            <input type="text" readonly name="collegeid" id="collegeid" value="<?php echo $row['collegename'];?>" class="form-control">
                        </div>
                        <div class="form-group col-md-8">                      
                            <textarea name="comments" id="comments" class="form-control" placeholder="post your comments"></textarea>
                        </div>
                        <div class="form-group col-md-8">                      
                        <input type="submit" name="submit" value="SEND" class="btn btn-primary">
                        </div>
                    </form>            
                    </div>
                </div>				
                <table border="1" class="table">
                    <tr>
                        <th>Slno</th>
                        <th>Username</th>
                        <th>Comments</th>
                    </tr>
                <?php
                    $sql3="SELECT * FROM comments where userid=$id ORDER BY comment_id DESC";
                    $res3=mysqli_query($link,$sql3);           
                    $sl=1;
                    while($row3=mysqli_fetch_array($res3)){                            
                ?>
                    <tr>      
                         <td><?php echo $sl++;?></td>                 
                        <td><?php echo $row3['email']?></td>                                
                        <td><?php echo $row3['comments']?></td>                                
                    </tr>
                    <?php }?>
                </table>    
		<?php }?>
			</div>
			
		</div>		
	</div>
            <div class="clearfix"></div>
	<!---728x90--->
            <!-- content-section-ends -->
            <!-- footer-section-starts -->
            <div class="footer">
                <div class="container">
                    <p class="wow fadeInLeft" data-wow-delay="0.4s">&copy; 2018 College Infopedia. All rights  Reserved</p>
                </div>
            </div>
            <!-- footer-section-ends -->
            <script type="text/javascript">
                $(document).ready(function() {

                    $().UItoTop({ easingType: 'easeOutQuart' });

                });
            </script>
            <a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

        </body>    
</html>