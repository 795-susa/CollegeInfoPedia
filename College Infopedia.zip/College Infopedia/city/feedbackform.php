<!DOCTYPE html>
<html>
<head>
	<title>feedback</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<?php 
        /*session_start();
        if ($_SESSION['email'] == "")
        {
          header('location:home.php');
        }
        else
        {
          $email = $_SESSION['email'];
          echo $email;
        }
echo $email;
$id = $_GET['var'];
	echo $id;*/

if(!isset($_POST['submit']))
{
?>

<div class="jumbotron" >
<div class="row">
<div class="col-sm-4"></div>
<div class="col-sm-4">
    <h3 style="color: green;">User Email</h3>
	<form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">
		<div class="form-group">
			<input type="text" value="" class="form-control" placeholder="write your email" name="user">
		</div>
		
	<h3 style="color: green;">Write Your Review</h3>

	<form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">
		<div class="form-group">
			<textarea rows="5" cols="30" class="form-control" required="fill feedback" placeholder="write your feedback" name="content1"></textarea>
		</div>
		<div class="form-group">        
		<input type="submit" id="button" name="submit"  value="submit">
		<style type="text/css">
			#button
			{
				height: 35px;
				width: 80px; 
				border: 0px; 
				background-color: #57d15f;
				color: white;
			}
			#button:hover{
				background-color: #2fb037;
			}
		</style>
	</div>

	</form>
	<hr>
	<a href="demoview1.php" class="btn btn-success btn-lg">Back To website Forms</a>
</div>
</div>
</div>



<?php
}
else{
	include("dbconnect.php");

    $email=mysqli_real_escape_string($link, $_POST['user']);
	$content = mysqli_real_escape_string($link, $_POST['content1']);

	$sql= "INSERT INTO feedback(ProfileID, user_email, content)
	VALUES ('$id', '$email', '$content')";

	if(mysqli_query($link,$sql))
			{
				header("location:profileview.php?$id");
			}
			else
			{
				echo "not ok";
			}
}
?>


</body>
</html>

