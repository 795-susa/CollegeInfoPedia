<?php
    $servername = "localhost";
	$username="root";
	$password = "";
	$dbname= "crud_bootstrap";
	$ans = $_POST['ans'];
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error)
	{
		die("Connection failed:". $conn->connect_error);
    }
    session_start();
    $query="SELECT * from user where Answer = '$ans'";
    $result=mysqli_query($conn,$query);
    $count = mysqli_num_rows($result);
    if($count==1)
    {
        header("location:password_sent.php");
    }
    else
    {
         echo '<script> alert("Invalid Answer");</script>';	
        echo '<script> window.location.assign("../forgotpassword.php");
        </script>';
    }
?>

