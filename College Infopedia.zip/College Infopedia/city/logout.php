<?php 
session_start();
unset($_SESSION["admin"]);
session_destroy();

?>
<script>
    //alert("Logout..");
    window.location="../index.php";
</script>
