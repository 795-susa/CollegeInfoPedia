<?php
	include('conn.php');
	if(isset($_POST['show'])){
		?>
		<h4 align="center">COLLEGE OTHER DETAILS</h4> <br>
		<table class = "table table-bordered alert-warning table-hover">
			<thead>
				<th>Sl No.</th>
				<th>College</th>
				<th>Labs</th>
				<th> Wifi</th>
				<th>Girls Hostel</th>
				<th>Boys Hostel</th>
				<th>Canteen</th>
			    <th>Action</th>

			</thead>
				<tbody>
					<?php
        $sl=1;
						$quser=mysqli_query($conn,"select * from otherdetails,college WHERE otherdetails.college_id=college.userid ORDER BY otherdetails.other_id DESC");
						while($urow=mysqli_fetch_array($quser)){
							?>
								<tr>
									<td><?php echo $sl++; ?></td>
									<td><?php echo $urow['collegename']; ?></td>
									<td><?php echo $urow['labs']; ?></td>
									<td><?php echo $urow['wifi']; ?></td>
									<td><?php echo $urow['g_hostel']; ?></td>
									<td><?php echo $urow['b_hostel']; ?></td>
									<td><?php echo $urow['canteen']; ?></td>
									<td><button class="btn btn-success" data-toggle="modal" data-target="#edit<?php echo $urow['other_id']; ?>"><span class = "glyphicon glyphicon-pencil"></span> Edit</button> | <button class="btn btn-danger delete" value="<?php echo $urow['other_id']; ?>"><span class = "glyphicon glyphicon-trash"></span> Delete</button>
									<?php include('edit_modaloth.php'); ?>
									</td>
								</tr>
							<?php
						}
 
					?>
				</tbody>
			</table>
		<?php
	}
 
?>