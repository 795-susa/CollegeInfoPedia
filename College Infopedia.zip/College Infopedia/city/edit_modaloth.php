<div class="modal fade" id="edit<?php echo $urow['other_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<?php
		$n=mysqli_query($conn,"select * from `otherdetails` where other_id='".$urow['other_id']."'");
		$nrow=mysqli_fetch_array($n);
	?>
  <div class="modal-dialog" role="document">
    <div class="modal-content">
		<div class = "modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" onclick="javascript:window.location.reload()">&times;</span></button>
			<center><h3 class = "text-success modal-title">UPDATE FACILITY</h3></center>
		</div>
		<form method="post" id="other_updateform" enctype="multipart/form-data">
		<div class="modal-body">
		
		<div class="form-group">
                <label for="one">College</label>
                <?php
                $sql1="SELECT * from college";
                $result1=mysqli_query($conn,$sql1);
                ?>      
                <select name="college" id="college" class="form-control" required="required">
                    <option value="">---SELECT COLLEGE---</option>
                    <?php
                    while($row1=mysqli_fetch_array($result1,MYSQLI_ASSOC)) {
                    ?>
                    <option value="<?php echo $row1['userid'];?>" 
                            <?php 
                        if ($row1['userid']==$nrow['college_id']) 
                        { 
                            ?>
                            selected 
                            <?php 
                        } 
                            ?>>
                        <?php echo $row1['collegename'];?></option>										
                    <?php 
                    }
                    ?>
                </select>

            </div>
            
             <div class="form-group">
                <label for="one">Labs</label>
                <input type="text" value="<?php echo $nrow['labs']; ?>" id="ulb" name="ulb" class="form-control">
            </div>
             <div class="form-group ">
                        <label for="two" >Wifi</label>
                        <input type  = "text" id = "uwf" name="uwf" class = "form-control" value="<?php echo $nrow['wifi']; ?>">
                    </div>
                    <div class="form-group ">
                        <label for="one">Girls Hostel</label>
                        <input type  = "text" id = "ugh" name="ugh" class = "form-control" value="<?php echo $nrow['g_hostel']; ?>">
                    </div>
                    
                    <div class="form-group ">
                        <label for="one">Boys Hostel</label>
                        <input type  = "text" id = "ubh" name="ubh" class = "form-control" value="<?php echo $nrow['b_hostel']; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="one">Canteen</label>
                        <input type  = "text" id = "uct" name="uct" class = "form-control" value="<?php echo $nrow['canteen']; ?>">
                    </div>
            <input type="hidden" value="<?php echo $urow['other_id']; ?>" id="userid" name="userid" class="form-control">
		<input type="hidden" value="" id="edit" name="edit" class="form-control">
		</div>
		<div class="modal-footer">
			  <button type="submit" class="updateuser btn btn-success" value="<?php echo $urow['other_id']; ?>"><span class = "glyphicon glyphicon-floppy-disk"></span> Save</button>|
			 <button type="button" class="btn btn-default" data-dismiss="modal"><span class = "glyphicon glyphicon-remove" onclick="javascript:window.location.reload()"></span> Cancel</button>
		</div>
		</form>
    </div>
  </div>
</div>
