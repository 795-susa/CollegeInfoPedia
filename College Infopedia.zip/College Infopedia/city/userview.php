

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/animate.css">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://use.fontawesome.com/9a9708a6b3.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css">
   <style type="text/css">
    .navbar{
      margin: 5px;
      border-radius: 0px;
      border: 0px;
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
       
    }
    #sbutton{
      background-color: #2fcf67;
      border:0px;
      height: 30px;
      width: 70px;
      color: white;
    }
    #sbutton:hover{
      background-color:green;
    }
    .navbar-default .navbar-brand{
      color: black;
    }
    .navbar-default .navbar-brand:hover{
      color: #3498DB;
    }
    .navbar-default .navbar-nav>li>a{
      color: #212F3D;
    }
    .navbar-default .navbar-nav>li>a:visited{
      color:black;
    }
    .navbar-default .navbar-nav>li>a:hover{
      background-color:#17202A;
      color:white;
    }
    .navbar-toggle{
      background-color: #5F6061;
    }
    #drop-menu:hover{
      color:black;
      background-color:  #B2B3B4;
    }

  </style>
</head>

<body>

  <!-- navabar section -->
  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=
        "#navbar-collapse">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href=""><big>CourseInfoPedia</big></a>
      </div>
      <div class="collapse navbar-collapse" id="navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
           <li><a style="color: #2E86C1; font-size: 20px;"><?php
        /*session_start();
        if ($_SESSION['email'] == "")
        {
          header('location:home.php');
        }
        else
        {
          $email = $_SESSION['email'];
          echo " Welcome To " .$email;
        }*/
      ?></a></li>
         <li><a class="navbarlinks"</a><a href="login1.php">LOGIN</a></li>
          <li><a class="navbarlinks"</a><a href="registration.php">REGISTER</a></li>
          
        </ul>
      </div>
    </div>
  </nav>
''

<?php 
include('dbconnect.php');
$sql=("SELECT * FROM college");
$select= mysqli_query($link, $sql);
if(!$select){
  printf("Error:%s\n",mysqli_error($link));
  exit();
  }
?>
<!-- sedebar menu section -->
 <div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav">
      <h3>Find Your Colleges</h3>

      <!-- search colleges form -->

     <form action="userview.php" method="POST">
          <div class="form-group">
              <label style="color: #2E86C1;">Search colleges:</label>
              <input type="text" class="form-control" placeholder="enter clollege name" name="search">
          </div>
          <div class="form-group">        
              <input id="sbutton" type="submit" name="" value="Go">
          </div>  
      </form> 
    </div><!--col-sm-3 tag close-->
	

    <div class="col-sm-9">
    <div class="jumbotron animated rollIn" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); border-radius: 0px; margin-top: 10px; border-bottom: 8px solid #f5b041;">
      <div class="container text-center">
        <h2 class="animated bounceInDown" style="color: #2E86C1;">
            Welcome To CourseInfoPedia
        </h2>
       
      </div>
    </div>

	

    <?php
include("dbconnect.php");
      

$output= '';
if(isset($_POST['search']))
{
  $searchq = $_POST['search'];
  $searchq = preg_replace("#[^0-9a-z]#i", "", $searchq);

  $query = mysqli_query($link,"SELECT * FROM college WHERE collegename LIKE '%$searchq%' ");

  $count = mysqli_num_rows($query);
  if($count == 0)
  {
    $output = 'there was no search!';
  }
  else
  {
    ?>
    <h1 style="color:green;">Your Search Results for <span style="color: #3498db"> <i><?php echo $searchq;?></i></span></h1>
    
    <?php 
    while ($row= mysqli_fetch_array($query)) 
    {
      ?>
         
        <div class="row" style="background-color: #d6eaf8; padding:20px 0px 20px 0px;"> 
        <div class="col-sm-2"></div>

        <div class="col-sm-8 bg23">


          <div class="col-sm-4">
 <img src="bvb2.jpg" style="width:200px; height:200px;">          </div>          </div>
          <div class="col-sm-8">

              <?php $var = $row['email']; ?>

              <p>College Name:<?php echo $row['collegename'] ?></p>
			  <p>Profile-Id:<b style="color: black;"><?php echo $row['ProfileID'] ?></b></p>
			  <p>Email-Id:<b style="color: black;"><?php echo $row['email'] ?></b></p>
              <p>Grade:<?php echo $row['grade'] ?></p>
              <p>Address:<?php echo $row['address'] ?></p>
              <p>Place:<?php echo $row['place'] ?></p>

              <p>
               <?php echo "<a href=profileview.php?var=$var >"."View More Information"."</a><br/>"; ?> </p>
              </p>

          </div>
        </div>
      </div>
    <?php
    }
  }
}
?>

       
  <style type="text/css">
  .bg23:hover{
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }
</style>   
</div><!-- container tag close -->
</body>


