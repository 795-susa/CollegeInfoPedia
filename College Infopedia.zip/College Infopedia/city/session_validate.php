<?php
session_start(); ?>


<?php
  if(!isset($_SESSION['admin'])||$_SESSION['admin']=="")
{ ?>
  
  <script type="text/javascript">
   alert("Session Expired");
  document.location="../index.php";      
</script>
  
  
<?php
}
?>