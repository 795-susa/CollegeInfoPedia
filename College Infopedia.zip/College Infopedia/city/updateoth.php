<?php
	include('conn.php');
	if(isset($_POST['edit'])){
		$id=$_POST['userid'];
		$college=$_POST['college'];
		$lb=$_POST['ulb'];
		$wf=$_POST['uwf'];
		$gh=$_POST['ugh'];
		$bh=$_POST['ubh'];
		$ct=$_POST['uct'];

 
		$sql=mysqli_query($conn,"update `otherdetails` set labs='$lb', wifi='$wf', g_hostel='$gh', b_hostel='$bh', canteen='$ct', college_id='$college'  where other_id='$id'");
        
        if($sql)
        {
            echo 'Successfully Updated';
        }
        else
        {
            echo 'Not Updated';
        }
	}
?>