<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/animate.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://use.fontawesome.com/9a9708a6b3.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css">
   <style type="text/css">
    .navbar{
      margin: 0px;
      border-radius: 0px;
      border: 0px;
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
       
    }
    
    .navbar-default .navbar-brand{
      color: black;
    }
    .navbar-default .navbar-brand:hover{
      color: #3498DB;
    }
    .navbar-default .navbar-nav>li>a{
      color: #212F3D;
    }
    .navbar-default .navbar-nav>li>a:visited{
      color:black;
    }
    .navbar-default .navbar-nav>li>a:hover{
      background-color:#17202A;
      color:white;
    }
    .navbar-toggle{
      background-color: #5F6061;
    }
    #drop-menu:hover{
      color:black;
      background-color:  #B2B3B4;
    }

  </style>
</head>

<body>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=
      "#navbar-collapse">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="userviewWebsite.php"><big>CollegeInfoPedia</big></a>
    </div>
    <div class="collapse navbar-collapse" id="navbar-collapse">
      <ul class="nav navbar-nav navbar-right">
         <li><a style="color: blue;"><?php
       /* session_start();
        if ($_SESSION['email'] == "")
        {
          header('location:home.php');
        }
        else
        {
          $email = $_SESSION['email'];
          echo $email;
        }*/
      ?></a></li>
        <li>  <a class="navbarlinks" href="userviewWebsite.php">LOGIN</a></li>
        <li><a class="navbarlinks" href="#">REGISTER</a></li>
        <li><a class="navbarlinks" href="#">CONTACT</a></li>
      </ul>
    </div>
  </div>
</nav>
  <?php
      include('dbconnect.php');
      
      // echo $col // get var form demoview1.php and store them in $col
      // now $col it contains the email of the college which is on clicked 
     // $email = $_GET['var'];

      $sql=("SELECT * FROM college");
      $select= mysqli_query($link, $sql);

   ?>
<!--jumbotron section -->





<div class="container">
  <div class="page-header">
      <h1>Feedback section</h1>

<?php
 $sql = ("SELECT * FROM Feedback");
 $select= mysqli_query($link, $sql);
 if(!$select){
  printf("Error:%s\n",mysqli_error($link));
  exit();
  }

?>
<div class="read-more">
<?php
while($userrow= mysqli_fetch_array($select))
{
?>  

<div class="container">
  <div class="row">
    <div class="col-sm-3">
      <div class="well text-center">
        <p class="glyphicon glyphicon-user" style="font-size: 50px;"></p>
        <p><?php echo $userrow['user_email'] ?></p>

      </div>
    </div> 
    <div class="col-sm-6">
      <div class="well">
        <p><?php echo $userrow['content'] ?></p>
      </div>
    </div>   
  </div>
</div>
<?php } ?>
</div>

      <button class="btn btn-default btn-lg">
      <?php echo "<a href=feedbackform.php>"."Feedback"."</a><br/>"; ?></button> 
  </div>
</div>
<!--footer section-->
<script type="text/javascript">
  $(document).ready(function function_name(){
    var readMoreHtml= $(".read-more").html();
    var lessText= readMoreHtml.substr(0,400);

    if (readMoreHtml.length>400){
      $(".read-more").html(lessText).append("<a href='' class='read-more-link'>Show more</a>");
    }else{
      $(".read-more").html(readMoreHtml);
    }

    $("body").on("click",".read-more-link", function(event){
      event.preventDefault();
      $(this).parent(".read-more").html(readMoreHtml).append("<a href='' class='show-less-link'>Show less</a>")
    });

    $("body").on("click",".show-less-link", function(event){
       event.preventDefault();
      $(this).parent(".read-more").html(readMoreHtml.substr(0,400)).append("<a href='' class='read-more-link'>Show more Feedbacks</a>")
    });
  });
</script>

<style type="text/css">
  .read-more-link, .show-less-link{
    color: #19a8f5;
    text-decoration: none;
    background-color: #e3e1da ;
    padding: 10px;
    margin-left: 40%;
    border-radius: 5px;
    border:1px solid black;
  }
  .read-more-link, .show-less-link:hover{
    text-decoration: none;
  }
</style>
</body>