<?php
	include('conn.php');
    include('dbconnect.php');
    include('session_validate.php');
?>
<!DOCTYPE html>
<html lang = "en">
	<head>
		<meta charset = "UTF-8" name = "viewport" content = "width-device=width, initial-scale=1" />
		<link rel = "stylesheet" type = "text/css" href = "bootstrap.css" />
		<title>CourseInfoPedia</title>
	</head>
<body>

    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><big>CourseInfoPedia</big></a>        
            </div>      
            <span style="float:right;margin-right:10px"><h4 class="btn btn-primary" onclick="window.location.href='logout.php'">LOGOUT</h4></span>
            <span style="float:right;margin-right:10px"><h4>&nbsp;</h4></span>
            <span style="float:right;margin-left:10px"><h4 class="btn btn-primary">Welcome <?php echo $_SESSION['admin'];?></h4></span>
        </div>
    </nav>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="viewcollege.php">View Colleges</a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="indexclg.php" class="navbar-brand">College Information</a></li>
                <li><a href="indexplc.php" class="navbar-brand">Placememt Information</a></li>
                <li><a href="indexlib.php" class="navbar-brand">Library Information</a></li>
                <li><a href="indexoth.php" class="navbar-brand">Facilities</a></li>
            </ul>
        </div>
    </nav>    
    
<div class="container-fluid">
    <div class="col-md-16 well">
        <div class="row">        
            <h2 align="center">COLLEGE LIST</h2> <br>
            <div class="container">
               <?php
                $quser=mysqli_query($conn,"select * from college order by userid DESC");
						while($urow=mysqli_fetch_array($quser)){
                ?>
               
                <div class="col-sm-3" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); border-radius: 0px; margin-top: 10px; margin-right: 10px; margin-left: 10px; border-bottom: 8px solid #f5b041;">
                    <img src="photos/<?php echo $urow['image']; ?>" alt="<?php echo $urow['image']; ?>" width="255" height="200" style="padding-top:15px;">
    
                        <h4><?php echo $urow['collegename']; ?></h4>  
                       
                </div>  
               <?php } ?>    
            </div>
        </div>        
    </div>
</div>
    
</body>
<script src = "js/jquery-3.3.1.min.js"></script>	
<script src = "js/bootstrap.js"></script>
</html>