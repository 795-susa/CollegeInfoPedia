
<!DOCTYPE html>
<html>
<head>
</script>
	<link rel="stylesheet" type="text/css" href="bootstrap-4.0.0-dist\css\bootstrap.min">
	<style type="text/css">
		.box{
			width: 500px;
			height: 250px;
			background-color: #c6d3d2;
		}
		.button3 {background-color: #f44336;}
		input[type=text], input[type=password] {
    width: 50%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}
	</style>
</head>
<body>
<center>
	<form action="forgotpswProcess.php" method="post" >
		<div class="box">
			<h1>Password Recovery</h1>
			email
			<input type="text" name="email">
			<br>
			<br>
			<input type="submit" class="button3"  onfocus="emailvalid()"  value="Next">
			</div>
		</form>
</center>
</body>
</html>