<?php
	include('conn.php');
	if(isset($_POST['show'])){
		?>
		<h4 align="center">COLLEGE LIBRARY DETAILS</h4> <br>
		<table class = "table table-bordered alert-warning table-hover">
			<thead>
				<th>Sl No.</th>
				<th>College</th>
				<th>Domain</th>
				<th>No of Books</th>
				<th>No of Magzines</th>
				<th>Reading Hours</th>
				<th>Action</th>

			</thead>
				<tbody>
					<?php
        $sl=1;
						$quser=mysqli_query($conn,"select * from library,college WHERE library.college_id=college.userid ORDER BY library.library_id DESC");
						while($urow=mysqli_fetch_array($quser)){
							?>
								<tr>
									<td><?php echo $sl++; ?></td>
									<td><?php echo $urow['collegename']; ?></td>
									<td><?php echo $urow['Domain']; ?></td>
									<td><?php echo $urow['no_of_books']; ?></td>
									<td><?php echo $urow['no_of_mgzns']; ?></td>
									<td><?php echo $urow['reading_hours']; ?></td>
									<td><button class="btn btn-success" data-toggle="modal" data-target="#edit<?php echo $urow['library_id']; ?>"><span class = "glyphicon glyphicon-pencil"></span> Edit</button> | <button class="btn btn-danger delete" value="<?php echo $urow['library_id']; ?>"><span class = "glyphicon glyphicon-trash"></span> Delete</button>
									<?php include('edit_modallib.php'); ?>
									</td>
								</tr>
							<?php
						}
 
					?>
				</tbody>
			</table>
		<?php
	}
 
?>