<?php
	include('conn.php');
	if(isset($_POST['ADD']))
    {
        
        $course=$_POST['course'];
        $city=$_POST['city'];
        $cn=$_POST['cn'];
		$em=$_POST['em'];
		$gr=$_POST['gr'];
		$ad=$_POST['ad'];
        
        $college_image=$_FILES['img']['name'];//original name
        $tmp_image=$_FILES['img']['tmp_name'];//temporary name
        $folder="photos/";

        $destination=$folder.$college_image;

        move_uploaded_file($tmp_image,$destination);
 
        $sql=mysqli_query($conn,"insert into `college` (course_id,city_id,collegename,email,grade,address,image) values ('$course','$city','$cn','$em','$gr','$ad','$college_image')");
        if($sql)
        {
            echo 'Successfully Inserted';
        }
        else
        {
            echo 'Not Inserted';
        }
	}
?>