<!DOCTYPE html>
<?php include('dbconnect.php');?>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/animate.css">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://use.fontawesome.com/9a9708a6b3.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css">
   <style type="text/css">
    .navbar{
      margin: 5px;
      border-radius: 0px;
      border: 0px;
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
       
    }
    #sbutton{
      background-color: #2fcf67;
      border:0px;
      height: 30px;
      width: 70px;
      color: white;
    }
    #sbutton:hover{
      background-color:green;
    }
    .navbar-default .navbar-brand{
      color: black;
    }
    .navbar-default .navbar-brand:hover{
      color: #3498DB;
    }
    .navbar-default .navbar-nav>li>a{
      color: #212F3D;
    }
    .navbar-default .navbar-nav>li>a:visited{
      color:black;
    }
    .navbar-default .navbar-nav>li>a:hover{
      background-color:#17202A;
      color:white;
    }
    .navbar-toggle{
      background-color: #5F6061;
    }
    #drop-menu:hover{
      color:black;
      background-color:  #B2B3B4;
    }

  </style>
</head>

<body>

  <!-- navabar section -->
  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=
        "#navbar-collapse">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href=""><big>CourseInfoPedia</big></a>
      </div>
      <div class="collapse navbar-collapse" id="navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
         <li><a class="navbarlinks"</a><a href="login1.php">LOGIN</a></li>
          <li><a class="navbarlinks"</a><a href="registration.php">REGISTER</a></li>
          
        </ul>
      </div>
    </div>
  </nav>
<!-- sedebar menu section -->
 <div class="container-fluid">
  <div class="row content">    	
    <div class="col-sm-12">
    <div class="jumbotron animated rollIn" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); border-radius: 0px; margin-top: 10px; border-bottom: 8px solid #f5b041;">
      <div class="container-fluid text-center">
        <h2 class="animated bounceInDown" style="color: #2E86C1;">
            <form method="post" name="f1" action="search_result.php">
            <div class="form-group col-sm-1"></div>
            <div class="form-group col-sm-4">
                <?php 
                $sql="SELECT * FROM course_category";
                $res=mysqli_query($link,$sql);                
                ?>
                <select name="course_name" id="course_name" class="form-control">
                <option value="">SELECT COURSE</option>
                <?php 
                while($row=mysqli_fetch_array($res)){
                ?>
                    <option value="<?php echo $row['course_id'];?>"><?php echo $row['course_name'];?></option>
                <?php }?>
                </select>                        
                
            </div>            
            <div class="form-group col-sm-4">
                <?php 
                $sql="SELECT * FROM cities";
                $res=mysqli_query($link,$sql);                
                ?>
                <select name="city_name" id="city_name" class="form-control">
                    <option value="">SELECT CITY</option>
                    <?php 
                    while($row=mysqli_fetch_array($res)){
                    ?>
                    <option value="<?php echo $row['city_id'];?>"><?php echo $row['city_name'];?></option>
                    <?php }?>
                </select>                        
            </div>            
            <div class="form-group col-sm-2">
                <input type="submit" name="submit" class="btn btn-primary" value="SEARCH">
            </div>
            </form>
        </h2>
       
      </div>
    </div>
      </div>
     </div>
  <style type="text/css">
  .bg23:hover{
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }
</style>   
</div><!-- container tag close -->
</body>
    

