<?php
	include('conn.php');
	if(isset($_POST['edit']))
    {
		$id=$_POST['userid'];
		$college=$_POST['college'];
		$comp=$_POST['ucomp'];
		$stud=$_POST['ustud'];
		$yr=$_POST['uyr'];
 
		$sql=mysqli_query($conn,"update `placement` set college_id='$college',comp_visited='$comp', stud_selected='$stud', year='$yr' where place_id='$id'");
        
        if($sql)
        {
            echo 'Successfully Updated';
        }
        else
        {
            echo 'Not Updated';
        }
	}
?>