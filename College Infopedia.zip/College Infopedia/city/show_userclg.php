<?php
	include('conn.php');
	if(isset($_POST['show'])){
		?>
		 <h4 align="center">COLLEGE DETAILS</h4> <br>
		<table class = "table table-bordered alert-warning table-hover">
			<thead>
                <th>Sl No.</th>
                <th>Course</th>
                <th>College Image</th>
				<th>College Name</th>
				<th>City</th>				
				<th>Email</th>
				<th>Grade</th>
				<th>Address</th>				
                <th>Action</th>
			</thead>
				<tbody>
					<?php
                        $sl=1;
						$quser=mysqli_query($conn,"select * from college c,course_category cc,cities ct where c.course_id=cc.course_id and c.city_id=ct.city_id order by c.userid DESC");
						while($urow=mysqli_fetch_array($quser)){
							?>
								<tr>
                                    <td><?php echo $sl++; ?></td>   
                                    <td><?php echo $urow['course_name']; ?></td>   
                                <td><img src="photos/<?php echo $urow['image']; ?>" alt="<?php echo $urow['image']; ?>" width="200" height="100"></td>   
								    <td><?php echo $urow['collegename']; ?></td>			<td><?php echo $urow['city_name']; ?></td>			
									<td><?php echo $urow['email']; ?></td>
									<td><?php echo $urow['grade']; ?></td>
									<td><?php echo $urow['address']; ?></td>									
									<td><button class="btn btn-success" data-toggle="modal" data-target="#edit<?php echo $urow['userid']; ?>"><span class = "glyphicon glyphicon-pencil"></span> Edit</button> | <button class="btn btn-danger delete" value="<?php echo $urow['userid']; ?>"><span class = "glyphicon glyphicon-trash"></span>Delete</button>
									<?php include('edit_modalclg.php'); ?>
									</td>
								</tr>
							<?php
						}
 
					?>
				</tbody>
			</table>
		<?php
	}
 
?>