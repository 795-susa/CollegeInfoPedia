<!DOCTYPE html>
<html lang="en">
 

<script>
function u_name()
{
	var uname1= f1.uname.value;
	var check= /^[a-zA-Z]{3,}$/;
	if (check.test(uname1))
	{
	}
	else
	{
		alert("invalid username");
		f1.uname.focus();
	}
}
function pwdvalid()
{
	var pwd1= f1.pwd.value;
	var check=/^(?=.*\d)(?=.*[a-zA-Z])([a-zA-Z0-9]{8,})$/;
    if (check.test(pwd1))
	{
	}
	else
	{
		alert("Password should contain atleast one digit,one lower case,one upper case with minimum length of 8 characters");
		f1.pwd.focus();
	}

}
function C_pwdvalid()
{
	var cpwd1= f1.pwd.value;
	var cpwd2= f1.cpwd.value;
	if (cpwd1 == cpwd2 && cpwd2.length > 5)
	{
	}
	else
	{
		alert("passowrd incorrect");
		f1.cpwd.focus();
	}
}

function mobvalid()
{
	var mob1= f1.mob.value;
	var check= /^[0-9]{10}$/;
	if (check.test(mob1))
	{
	}
	else
	{
		alert("Invalid mobile number");
		f1.mob.focus();
	}
}
function emailvalid() 
{
    var email1= f1.email1.value;
	if (email1.length != 0)
	{
	}	
	else
	{
		alert("Invalid email");
		f1.email1.focus();
	}
}
function ansvalid()
{
	var ans= f1.ans.value;
	if (ans.length != 0)
	{
	}
	else
	{
		alert("plzz enter the answer");
		f1.ans.focus();
	}
}
</script>
<nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=
        "#navbar-collapse">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href=""><big>CourseInfoPedia</big></a>
      </div>
      <div class="collapse navbar-collapse" id="navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
      
      </a></li>
         
        </ul>
      </div>
    </div>
  </nav>

<head>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<style>
@import "font-awesome.min.css";
@import "font-awesome-ie7.min.css";
/* Space out content a bit */
body {
  padding-top: 70px;
  padding-bottom: 20px;
}

/* Everything but the jumbotron gets side spacing for mobile first views */
.header,
.marketing,
.footer {
  padding-right: 15px;
  padding-left: 15px;
}

/* Custom page header */
.header {
  border-bottom: 0px solid #e5e5e5;
}
/* Make the masthead heading the same height as the navigation */
.header h3 {
  padding-bottom: 19px;
  margin-top: 0;
  margin-bottom: 0;
  line-height: 40px;
}

/* Custom page footer */
.footer {
  padding-top: 19px;
  color: #777;
  border-top: 1px solid #e5e5e5;
}

/* Customize container */
@media (min-width: 768px) {
  .container {
    max-width: 730px;
  }
}
.container-narrow > hr {
  margin: 30px 0;
}

/* Main marketing message and sign up button */
.jumbotron {
  text-align: center;
  border-bottom: 1px solid #e5e5e5;
}
.jumbotron .btn {
  padding: 14px 24px;
  font-size: 21px;
}

/* Supporting marketing content */
.marketing {
  margin: 40px 0;
}
.marketing p + h4 {
  margin-top: 28px;
}

/* Responsive: Portrait tablets and up */
@media screen and (min-width: 768px) {
  /* Remove the padding we set earlier */
  .header,
  .marketing,
  .footer {
    padding-right: 0;
    padding-left: 0;
  }
  /* Space out the masthead */
  .header {
    margin-bottom: 30px;
  }
  /* Remove the bottom border on the jumbotron for visual effect */
  .jumbotron {
    border-bottom: 0;
  }
  
     .navbar{
      margin: 0px;
      border-radius: 0px;
      border: 0px;
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
       
    }
    #sbutton{
      background-color: #2fcf67;
      border:0px;
      height: 30px;
      width: 70px;
      color: white;
    }
    #sbutton:hover{
      background-color:green;
    }
    .navbar-default .navbar-brand{
      color: black;
    }
    .navbar-default .navbar-brand:hover{
      color: #3498DB;
    }
    .navbar-default .navbar-nav>li>a{
      color: #212F3D;
    }
    .navbar-default .navbar-nav>li>a:visited{
      color:black;
    }
    .navbar-default .navbar-nav>li>a:hover{
      background-color:#17202A;
      color:white;
    }
    .navbar-toggle{
      background-color: #5F6061;
    }
    #drop-menu:hover{
      color:black;
      background-color:  #B2B3B4;
    }
}
</style>

</head>

<div class="container">
    <h1 class="well">Register Here</h1>
	<div class="col-lg-12 well">
	<div class="row">
	<form name="f1" action="process_register.php" method="post">

	                    <div class="col-sm-6 form-group">
						    <label>Select Role</label>
						    <select name="role">
				            <option value="Admin">Admin</option>
				            <option value="User">User</option>
  				            </select>
						</div>
	                    </div>
						
						<div class="form-group">
							<label>Username</label>
							<input type="text" name="uname" min="3" max="15" class="form-control">
						</div>
						
						<div class="row">
    						<div class="col-sm-6 form-group">
    							<label>Password</label>
                                <input type="password"  class="form-control" name="pwd" min="8" max="15" onfocus="u_name()">  
						</div>
						
    					<div class="col-sm-6 form-group">
    							<label>Confirm Password</label>
    							<input type="password" name="cpwd" onfocus="pwdvalid()" class="form-control">
    						</div>
	                    </div>
						
						<div class="form-group">
						    <label>Mobile</label>
                            <input type="text" name="mob" maxlength="10" onfocus="C_pwdvalid()" class="form-control">
    					</div>
						
    					<div class="form-group">
    						<label>Email Address</label>
    						<input type="email" name="email1" onfocus="mobvalid()" class="form-control">
    					</div>	  
						
						<div class="row">
    					<div class="col-sm-6 form-group">
						<label>Select Question</label>
						<select class="form control" name="Question">
				        <option value="What is Your School Name?">What is Your School Name?</option>
				        <option value="Which is your birth place?">Which is your birth place?</option>
				        <option value="What is Your favorite Movie?">What is Your favorite Movie?</option>
				        <option value="What is Your birth Name?">What is Your birth Name?</option>
				        <option value="what is Your Bike Number?">what is Your Bike Number?</option>
				        <option value="who is your first class teacher in school?</">who is your first class teacher in school?</option>
				        <option value="when is your Brother Birthday?">when is your Brother Birthday?</option>
				        <option value="What is your pet name?">What is your pet name?</option>
  				        </select>
				        </div>
						
						<div class="col-sm-6 form-group">
					    <label>Answer</label>
    					<input type="text"  name="ans" onfocus="emailvalid()"class="form-control">
    					</div>
	                    </div>

	                     
					    <button type="Submit"  name="REGISTER" onfocus="ansvalid()" onclick="login.php()" class="btn btn-lg btn-info">Register</button>		
                        <br>
						<a href="login1.php">Already registered??? Login</a>
						
					</div>
				</form> 
		</div>
	</div>
</div>