<?php
	include('conn.php');
	if(isset($_POST['del'])){
		$id=$_POST['id'];
		$sql=mysqli_query($conn,"delete from `library` where library_id='$id'");
        
        if($sql)
        {
            echo "Successfully Deleted";
        }
        else
        {
            echo "Not Deleted";
        }
	}
?>