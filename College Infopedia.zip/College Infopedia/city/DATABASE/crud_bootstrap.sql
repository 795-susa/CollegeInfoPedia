-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2018 at 08:58 AM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud_bootstrap`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `userid` int(11) NOT NULL,
  `ProfileID` varchar(50) NOT NULL,
  `categoryname` varchar(50) NOT NULL,
  `program` varchar(50) NOT NULL,
  `stream` varchar(50) NOT NULL,
  `categoryid` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `city_id` int(11) NOT NULL,
  `city_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`city_id`, `city_name`) VALUES
(1, 'DHARWAD'),
(2, 'HUBLI'),
(3, 'BELGAUM'),
(4, 'BANGLORE');

-- --------------------------------------------------------

--
-- Table structure for table `college`
--

CREATE TABLE `college` (
  `userid` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `collegename` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `grade` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `college`
--

INSERT INTO `college` (`userid`, `course_id`, `city_id`, `collegename`, `email`, `grade`, `address`, `image`) VALUES
(4, 3, 3, 'KUDh', 'KUDj@gmail.com', 'jj', 'jjjjjj', '356.jpg'),
(16, 2, 4, 'kkk', 'kkkk', 'kkk', 'kkkk', '222.jpg'),
(17, 2, 2, 'BVB', 'bvbcollege@gmail.com', 'A', 'HUBBALLI', 'prop2.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `course_category`
--

CREATE TABLE `course_category` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_category`
--

INSERT INTO `course_category` (`course_id`, `course_name`) VALUES
(1, 'PUC COLLEGES'),
(2, 'DEGREE COLLEGES'),
(3, 'PG COLLEGES');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `ProfileID` varchar(50) NOT NULL,
  `user_email` varchar(20) NOT NULL,
  `content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`ProfileID`, `user_email`, `content`) VALUES
('', 'sush@gmail.com', 'good facilities..'),
('', 'madhu@gmail.com', 'good one'),
('', 'madhu@gmail.com', 'nyc'),
('', 'sush', 'adbcd');

-- --------------------------------------------------------

--
-- Table structure for table `library`
--

CREATE TABLE `library` (
  `library_id` int(255) NOT NULL,
  `college_id` int(11) NOT NULL,
  `Domain` varchar(30) NOT NULL,
  `no_of_books` int(255) NOT NULL,
  `no_of_mgzns` int(20) NOT NULL,
  `reading_hours` int(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `library`
--

INSERT INTO `library` (`library_id`, `college_id`, `Domain`, `no_of_books`, `no_of_mgzns`, `reading_hours`) VALUES
(17, 1, 'mca', 123, 124, 5),
(18, 4, 'kp', 0, 0, 0),
(19, 16, '99', 99, 99, 99);

-- --------------------------------------------------------

--
-- Table structure for table `otherdetails`
--

CREATE TABLE `otherdetails` (
  `other_id` int(11) NOT NULL,
  `labs` varchar(50) NOT NULL,
  `wifi` varchar(50) NOT NULL,
  `g_hostel` varchar(50) NOT NULL,
  `b_hostel` varchar(50) NOT NULL,
  `canteen` varchar(50) NOT NULL,
  `college_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `otherdetails`
--

INSERT INTO `otherdetails` (`other_id`, `labs`, `wifi`, `g_hostel`, `b_hostel`, `canteen`, `college_id`) VALUES
(8, '3', 'yes', 'yes', 'no', 'yes', 1);

-- --------------------------------------------------------

--
-- Table structure for table `placement`
--

CREATE TABLE `placement` (
  `place_id` int(11) NOT NULL,
  `college_id` int(11) NOT NULL,
  `comp_visited` varchar(50) NOT NULL,
  `stud_selected` varchar(50) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `placement`
--

INSERT INTO `placement` (`place_id`, `college_id`, `comp_visited`, `stud_selected`, `year`) VALUES
(10, 17, '20', '20', 2018);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `role` varchar(10) NOT NULL,
  `UserName` varchar(30) NOT NULL,
  `Password` varchar(60) NOT NULL,
  `Mobile` varchar(10) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Question` varchar(50) NOT NULL,
  `Answer` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`role`, `UserName`, `Password`, `Mobile`, `Email`, `Question`, `Answer`) VALUES
('User', 'sushmita', 'aaaa1234', '8978651231', 'sus@gmail.com', 'What is Your School Name?', 'aa'),
('User', 'sachin', 'sach2828', '9060044728', 'sach@gmail.com', 'What is your pet name?', 'sachi'),
('Admin', 'madhu', '1234madhu', '8978651231', 'madh@gmail.com', 'What is Your favorite Movie?', 'gulto'),
('Admin', 'karthik', 'karthi1234', '8888888888', 'abmadhuam@gmail.com', 'Which is your birth place?', 'hubli'),
('User', 'madhuam', 'Madhu123', '8978651231', 'madhu@gmail.com', 'What is Your favorite Movie?', 'abc'),
('User', 'gangu', '79d332983560e3e23fc1a8c95200bf65', '2314456712', 'gangu@gmail.com', 'What is Your School Name?', 'asdfgh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `categoryid` (`categoryid`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `college`
--
ALTER TABLE `college`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `course_category`
--
ALTER TABLE `course_category`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `library`
--
ALTER TABLE `library`
  ADD PRIMARY KEY (`library_id`);

--
-- Indexes for table `otherdetails`
--
ALTER TABLE `otherdetails`
  ADD PRIMARY KEY (`other_id`);

--
-- Indexes for table `placement`
--
ALTER TABLE `placement`
  ADD PRIMARY KEY (`place_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `city_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `college`
--
ALTER TABLE `college`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `course_category`
--
ALTER TABLE `course_category`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `library`
--
ALTER TABLE `library`
  MODIFY `library_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `otherdetails`
--
ALTER TABLE `otherdetails`
  MODIFY `other_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `placement`
--
ALTER TABLE `placement`
  MODIFY `place_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
