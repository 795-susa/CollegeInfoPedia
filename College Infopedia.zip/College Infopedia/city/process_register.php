<?php 
	$servername = "localhost";
	$username= "root";
	$password = "";
	$dbname= "crud_bootstrap";
	$encrpt=md5($pw);

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	
	// Check connection
	if ($conn->connect_error)
	{
		die("Connection failed:". $conn->connect_error);
	}

	// Create database
	$sql = "insert into user (role,UserName,Password,Mobile,Email,Question,Answer) values
	('$_POST[role]',
	'$_POST[uname]',
	'$_POST[pwd]',	
	'$_POST[mob]',
	'$_POST[email1]',
	'$_POST[Question]',
   '$_POST[ans]')";
	if ($conn->query($sql) === TRUE)
	{
	echo '<script> window.location.assign("../login.php"); </script>';

	}
	else
	{
	echo "Error inserting data: "
	. $conn->error;
	}
	$conn->close();
	?>