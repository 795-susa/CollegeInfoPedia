<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="home.php"><big>CoursePedia</big></a>
    </div>
    <div class="collapse navbar-collapse" id="navbar-collapse">
      <ul class="nav navbar-nav navbar-right">
        <li><a class="navbarlinks"</a><a href="login.php">LOGIN</a></li>
          <li><a class="navbarlinks"</a><a href="registration.php">REGISTER</a></li>
          <li><a class="navbarlinks"</a><a href="#">CONTACT</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="jumbotron">
	
	<div class="container text-center">
		<div class="btn-group-vertical">
			<a href="indexclg.php" class="btn btn-success btn-lg">College Details</a><hr>
			<a href="indexplc.php" class="btn btn-success btn-lg">Placements Details</a><hr>
			<a href="feedbackview.php" class="btn btn-success btn-lg">Feedback Details</a><hr>
			<a href="indexlib.php" class="btn btn-success btn-lg">Library Details</a><hr>
			<a href="indexoth.php" class="btn btn-success btn-lg">Other Details</a>
		</div>
	</div>
</body>
</html>