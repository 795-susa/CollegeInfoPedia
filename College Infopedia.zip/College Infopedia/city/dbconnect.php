<?php
$host= 'localhost';
$username ='root';
$password='';
$database='crud_bootstrap';

$link = mysqli_connect($host, $username, $password, $database);
if($link === false)
{
	die("error: could not connect" . mysqli_connect_error());
}
?>