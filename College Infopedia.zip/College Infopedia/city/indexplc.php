<?php
	include('conn.php');
    include('dbconnect.php');
    include('session_validate.php');
?>
<!DOCTYPE html>
<html lang = "en">
	<head>
		<meta charset = "UTF-8" name = "viewport" content = "width-device=width, initial-scale=1" />
		<link rel = "stylesheet" type = "text/css" href = "bootstrap.css" />
		<title>CourseInfoPedia</title>
	</head>
<body>

    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><big>CourseInfoPedia</big></a>        
            </div>      
            <span style="float:right;margin-right:10px"><h4 class="btn btn-primary" onclick="window.location.href='logout.php'">LOGOUT</h4></span>
            <span style="float:right;margin-right:10px"><h4>&nbsp;</h4></span>
            <span style="float:right;margin-left:10px"><h4 class="btn btn-primary">Welcome <?php echo $_SESSION['admin'];?></h4></span>
        </div>
    </nav>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="viewcollege.php">View Colleges</a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="indexclg.php" class="navbar-brand">College Information</a></li>
                <li><a href="indexplc.php" class="navbar-brand">Placememt Information</a></li>
                <li><a href="indexlib.php" class="navbar-brand">Library Information</a></li>
                <li><a href="indexoth.php" class="navbar-brand">Facilities</a></li>
            </ul>
        </div>
    </nav>    
    
<div class="container-fluid">
    <div class="col-md-16 well">
        <div class="row">        
            
            <div class="container">
                <h4 align="center">ADD COLLEGE PLACEMENT DETAILS</h4> <br>
                <form method="post" id="placement_form" enctype="multipart/form-data">
                <div class="row">
                    <div class="form-group col-md-3">
                        <label for="one">College</label>
                        <?php 
                        $sql="SELECT * FROM college";
                        $res=mysqli_query($link,$sql);                
                        ?>
                        <select name="college" id="college" class="form-control">
                            <option value="">SELECT COLLEGE</option>
                            <?php 
                            while($row=mysqli_fetch_array($res)){
                            ?>
                            <option value="<?php echo $row['userid'];?>"><?php echo $row['collegename'];?></option>
                            <?php }?>
                        </select>                        
                    </div>
                    <div class="form-group col-md-3">
                        <label for="one">Companies Visited</label>
                        <input type  = "text" id = "comp" name="comp" class = "form-control">
                    </div>

                    <div class="form-group col-md-3">
                        <label for="two" >Students Selected</label>
                        <input type  = "text" id = "stud" name="stud" class = "form-control">
                    </div>
                    <div class="form-group col-md-3">
                        <label for="one">Year</label>
                        <input type  = "text" id = "yr" name="yr" class = "form-control">
                    </div>

                    <div class="form-group col-md-12">
                       <input type="hidden" id="ADD" name="ADD">
                        <button type="submit" id="addnew" name="addnew" class = "btn btn-primary"><span class = "glyphicon glyphicon-plus"></span> Add</button>
                    </div>
                </div>
                </form>
            </div>
        </div>        
    </div>
</div>
    
    <div class="container-fluid">
        <div class="col-md-16 well">
            <div class="row">        
                <div id="userTable"></div>
            </div>
        </div>
    </div>

</body>
<script src = "js/jquery-3.3.1.min.js"></script>	
<script src = "js/bootstrap.js"></script>
<script type = "text/javascript">
	$(document).ready(function(){
		showUser();
		//Add New
		$(document).on('submit', '#placement_form', function(event) {
            event.preventDefault();
			if ($('#comp').val()=="" || $('#stud').val()=="" || $('#yr').val()=="" || $('#college').val()=="" )
            {
				alert('Please input data first');
			}
			else{		
				$.ajax({
                    url: "addnewplc.php",
					method: "POST",
					data: new FormData(this),
                    contentType: false,
                    processData: false,
					success: function(data){
                        alert(data);
                        location.reload();
						showUser();
					}
				});
			}
		});
		//Delete
		$(document).on('click', '.delete', function(){
			$id=$(this).val();
				$.ajax({
					type: "POST",
					url: "deleteplc.php",
					data: {
						id: $id,
						del: 1,
					},
					success: function(data){
                        alert(data);
						showUser();
					}
				});
		});
		//Update
		$(document).on('submit', '#placement_updateform', function(event) {
            event.preventDefault();
			$uid=$("#userid").val();
			$('#edit'+$uid).modal('hide');
			$('body').removeClass('modal-open');
			$('.modal-backdrop').remove();
				$.ajax({
                    url: "updateplc.php",
					method: "POST",
					data: new FormData(this),
                    contentType: false,
                    processData: false,
					success: function(data){
                        alert(data);
                        location.reload();
						showUser();
					}
				});
		});
 
	});
 
	//Showing our Table
	function showUser(){
		$.ajax({
			url: 'show_userplc.php',
			type: 'POST',
			async: false,
			data:{
				show: 1
			},
			success: function(response){
				$('#userTable').html(response);
			}
		});
	}
 
</script>

</html>