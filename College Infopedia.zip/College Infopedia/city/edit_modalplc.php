<div class="modal fade" id="edit<?php echo $urow['place_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<?php
		$n=mysqli_query($conn,"select * from `placement` where place_id='".$urow['place_id']."'");
		$nrow=mysqli_fetch_array($n);
	?>
  <div class="modal-dialog" role="document">
    <div class="modal-content">
		<div class = "modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" onclick="javascript:window.location.reload()">&times;</span></button>
			<center><h3 class = "text-success modal-title">UPDATE PLACEMENT</h3></center>
		</div>
		<form method="post" id="placement_updateform" enctype="multipart/form-data">
		<div class="modal-body">
		
		<div class="form-group">
                <label for="one">College</label>
                <?php
                $sql1="SELECT * from college";
                $result1=mysqli_query($conn,$sql1);
                ?>      
                <select name="college" id="college" class="form-control" required="required">
                    <option value="">---SELECT COLLEGE---</option>
                    <?php
                    while($row1=mysqli_fetch_array($result1,MYSQLI_ASSOC)) {
                    ?>
                    <option value="<?php echo $row1['userid'];?>" 
                            <?php 
                        if ($row1['userid']==$nrow['college_id']) 
                        { 
                            ?>
                            selected 
                            <?php 
                        } 
                            ?>>
                        <?php echo $row1['collegename'];?></option>										
                    <?php 
                    }
                    ?>
                </select>

            </div>
            
             <div class="form-group">
                <label for="one">Companies Visited</label>
                <input type="text" value="<?php echo $nrow['comp_visited']; ?>" id="ucomp" name="ucomp" class="form-control">
            </div>
             <div class="form-group">
                <label for="one">Students Selected</label>
                <input type="text" value="<?php echo $nrow['stud_selected']; ?>" id="ustud" name="ustud" class="form-control">
            </div>
             <div class="form-group">
                <label for="one">Year</label>
                <input type="text" value="<?php echo $nrow['year']; ?>" id="uyr" name="uyr" class="form-control">
            </div>
            <input type="hidden" value="<?php echo $urow['place_id']; ?>" id="userid" name="userid" class="form-control">
		<input type="hidden" value="" id="edit" name="edit" class="form-control">
		</div>
		<div class="modal-footer">
			  <button type="submit" class="updateuser btn btn-success" value="<?php echo $urow['place_id']; ?>"><span class = "glyphicon glyphicon-floppy-disk"></span> Save</button>|
			 <button type="button" class="btn btn-default" data-dismiss="modal"><span class = "glyphicon glyphicon-remove" onclick="javascript:window.location.reload()"></span> Cancel</button>
		</div>
		</form>
    </div>
  </div>
</div>