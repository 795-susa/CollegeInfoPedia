<?php
	include('conn.php');
	if(isset($_POST['ADD'])){
	    $lb=$_POST['lb'];
		$wf=$_POST['wf'];
		$gh=$_POST['gh'];
		$bh=$_POST['bh'];
		$ct=$_POST['ct'];
		$college=$_POST['college'];

		
		$sql=mysqli_query($conn,"insert into `otherdetails` (labs, wifi, g_hostel, b_hostel, canteen, college_id) values ('$lb', '$wf','$gh','$bh','$ct','$college')");
        
        if($sql)
        {
            echo 'Successfully Inserted';
        }
        else
        {
            echo 'Not Inserted';
        }
	}
?>
