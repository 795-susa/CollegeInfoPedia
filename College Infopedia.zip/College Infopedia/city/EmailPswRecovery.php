

<!DOCTYPE html>
<html>
<head>
<head>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link rel="stylesheet" type="text/css" href="bootstrap-4.0.0-dist\css\bootstrap.min">
	<style type="text/css">
		.box{
			width: 500px;
			height: 250px;
			background-color: #c6d3d2;
		}
		.button3 {background-color: #f44336;}
		input[type=text], input[type=password] {
    width: 50%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}
	</style>
</head>
<body>
<?php 
    
    $servername = "localhost";
	$username="root";
	$password = "";
	$dbname= "crud_bootstrap";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error)
	{
		die("Connection failed:". $conn->connect_error);
    }
    session_start();
    $email = $_SESSION['email'];
    $query="SELECT * from user where Email = '$email'";
    $result=mysqli_query($conn,$query);
    while ($row= mysqli_fetch_array($result)) 
    {
?>
<center>
	<form name="f1" method="post" action="EmailPswRecoveryProcess.php">
		<div class="box">
		<div class="form-group">
		<div class="form-group">
			<h1>Password Recovery</h1>
			Question
            
			</div>
			<div class="form-group">
            <?php echo $row['Question']; ?>
			</div>
            <div class="form-group">
            Enter You Answer
			<input type="text" name="ans">
			</div>
			<div class="form-group">
			<input type="submit" class="button3" name="submit" value="Next">
			</div>
			</div>
		</form>
</center>
<?php
    }
?>
</body>
</html>