<?php
	include('conn.php');
	if(isset($_POST['edit'])){
        
		$id=$_POST['userid'];
		$college=$_POST['college'];
		$dom=$_POST['udom'];
		$nob=$_POST['unob'];
		$nom=$_POST['unom'];
		$rh=$_POST['urh'];
 
		$sql=mysqli_query($conn,"update `library` set college_id='$college', Domain='$dom', no_of_books='$nob',  no_of_mgzns='$nom', reading_hours='$rh' where library_id='$id'");
        
        if($sql)
        {
            echo 'Successfully Updated';
        }
        else
        {
            echo 'Not Updated';
        }
	}
?>