<?php
	include('conn.php');
	if(isset($_POST['del'])){
		$id=$_POST['id'];
		$sql=mysqli_query($conn,"delete from `placement` where place_id='$id'");
        if($sql)
        {
            echo "Successfully Deleted";
        }
        else
        {
            echo "Not Deleted";
        }
	}
?>