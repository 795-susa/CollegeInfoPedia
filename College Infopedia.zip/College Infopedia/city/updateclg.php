<?php
	include('conn.php');
	if(isset($_POST['edit'])){
		$id=$_POST['userid'];
        $cn=$_POST['ucn'];
  		$course=$_POST['ucourse'];
		$em=$_POST['uem'];
		$gr=$_POST['ugr'];
		$ad=$_POST['uad'];
		$city=$_POST['ucity'];
 
        
        if(!empty($_FILES['uimg']['name']))
        {
            $college_image=$_FILES['uimg']['name'];//original name
            $tmp_image=$_FILES['uimg']['tmp_name'];//temporary name
            $folder="photos/";
            $destination=$folder.$college_image;
            move_uploaded_file($tmp_image,$destination);   
        }
        else
        {
            $college_image=$_POST['old_image'];
        }
        
        
		$sql=mysqli_query($conn,"update `college` set course_id='$course',city_id='$city',collegename='$cn',email='$em', grade='$gr', address='$ad',image='$college_image'  where userid='$id'");
        
        if($sql)
        {
            echo 'Successfully Updated';
        }
        else
        {
            echo 'Not Updated';
        }
	}
?>