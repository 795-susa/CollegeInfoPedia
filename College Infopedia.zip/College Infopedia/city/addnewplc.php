<?php
	include('conn.php');
	if(isset($_POST['ADD']))
    {
        
	    $college=$_POST['college'];
	    $comp=$_POST['comp'];
		$stud=$_POST['stud'];
		$yr=$_POST['yr'];		
            
		$sql=mysqli_query($conn,"insert into `placement` (college_id,comp_visited, stud_selected, year) values ('$college','$comp', '$stud','$yr')");
        
        if($sql)
        {
            echo 'Successfully Inserted';
        }
        else
        {
            echo 'Not Inserted';
        }
	}
?>
