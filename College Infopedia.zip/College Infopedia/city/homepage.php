<DOCTYPE html>
<html lang="en">
<head>
<title>Course Info Pedia</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Unicat project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="styles/responsive.css">
</head>
<body>

<div class="super_container">

	<!-- Header -->

	<header class="header">
			
		<!-- Top Bar -->
		<div class="top_bar">
			<div class="top_bar_container">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
								<ul class="top_bar_contact_list">
									<li><div class="question">Have any questions?</div></li>
									<li>
										<i class="fa fa-phone" aria-hidden="true"></i>
										<div>777-888-9999</div>
									</li>
									<li>
										<i class="fa fa-envelope-o" aria-hidden="true"></i>
										<div>info.sushmita@gmail.com</div>
									</li>
								</ul>
								<div class="top_bar_login ml-auto">
									<div class="login_button"><a href="login.php">Login</a></div>
									<div class="register_button"><a href="">Register</a></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>				
		</div>

		<!-- Header Content -->
		<div class="header_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_content d-flex flex-row align-items-center justify-content-start">
							<div class="logo_container">
								<a href="#">
									<div class="logo_text">Course<span>InfoPedia</span></div>
								</a>
							</div>
							<nav class="main_nav_contaner ml-auto">
								<ul class="main_nav">
									<li class="active"><a href="#">Home</a></li>
									<li><a href="about.html">About</a></li>
									<li><a href="contact.html">Contact</a></li>
								</ul>
								
								<!-- Hamburger 
								<div class="search_button"><i class="fa fa-search" aria-hidden="true"></i></div>
								<div class="shopping_cart"><i class="fa fa-shopping-cart" aria-hidden="true"></i></div>
								<div class="hamburger menu_mm">
									<i class="fa fa-bars menu_mm" aria-hidden="true"></i>
								</div>-->
							</nav>

						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Header Search Panel -->
		<div class="header_search_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_search_content d-flex flex-row align-items-center justify-content-end">
							<form action="#" class="header_search_form">
								<input type="search" class="search_input" placeholder="Search" required="required">
								<button class="header_search_button d-flex flex-column align-items-center justify-content-center">
									<i class="fa fa-search" aria-hidden="true"></i>
								</button>
							</form>
						</div>
					</div>
				</div>
			</div>			
		</div>			
	</header>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

* {
    box-sizing: border-box;
}

form.example input[type=text] {
    padding: 6px;
    font-size: 17px;
    border: 1px solid grey;
    float: left;
    width: 80%;
    background: #f1f1f1;
}

form.example button {
    float: left;
    width: 20%;
    padding: 10px;
    background: #2196F3;
    color: white;
    font-size: 17px;
    border: 1px solid grey;
    border-left: none;
    cursor: pointer;
}

form.example button:hover {
    background: #0b7dda;
}

form.example::after {
    content: "";
    clear: both;
    display: table;
}
</style>
</head>
<body background="transparent">

<?php 
include('dbconnect.php');
$sql=("SELECT * FROM college");
$select= mysqli_query($link, $sql);
if(!$select){
  printf("Error:%s\n",mysqli_error($link));
  exit();
  }
?>
</br></br></br></br></br></br></br></br></br></br></br></br>
<form class="example" action="homepage.php" style="margin:auto;max-width:700px">
  <input type="text" placeholder="Search.." name="search2">
  <button type="submit"><i class="fa fa-search"></i></button>
</form>


    <?php
include("dbconnect.php");
      

$output= '';
if(isset($_POST['search']))
{
  $searchq = $_POST['search'];
  $searchq = preg_replace("#[^0-9a-z]#i", "", $searchq);

  $query = mysqli_query($link,"SELECT * FROM college WHERE collegename LIKE '%$searchq%' ");

  $count = mysqli_num_rows($query);
  if($count == 0)
  {
    $output = 'there was no search!';
  }
  else
  {
    ?>
    <h1 style="color:green;">Your Search Results for <span style="color: #3498db"> <i><?php echo $searchq;?></i></span></h1>
    
    <?php 
    while ($row= mysqli_fetch_array($query)) 
    {
      ?>
         
        <div class="row" style="background-color: #d6eaf8; padding:20px 0px 20px 0px;"> 
        <div class="col-sm-2"></div>

        <div class="col-sm-8 bg23">


          <div class="col-sm-4">
 <img src="bvb2.jpg" style="width:200px; height:200px;">          </div>          </div>
          <div class="col-sm-8">

              <?php $var = $row['email']; ?>

              <p>College Name:<?php echo $row['collegename'] ?></p>
			  <p>Profile-Id:<b style="color: black;"><?php echo $row['ProfileID'] ?></b></p>
			  <p>Email-Id:<b style="color: black;"><?php echo $row['email'] ?></b></p>
              <p>Grade:<?php echo $row['grade'] ?></p>
              <p>Address:<?php echo $row['address'] ?></p>
              <p>Place:<?php echo $row['place'] ?></p>

              <p>
               <?php echo "<a href=profileview.php?var=$var >"."View More Information"."</a><br/>"; ?> </p>
              </p>

          </div>
        </div>
      </div>
    <?php
    }
  }
}
?>

       
  <style type="text/css">
  .bg23:hover{
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }
</style>   

</body>
</html>

<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="UTF-8" />
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        <title>Login and Registration Form with HTML5 and CSS3</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <meta name="description" content="Login and Registration Form with HTML5 and CSS3" />
        <meta name="keywords" content="html5, css3, form, switch, animation, :target, pseudo-class" />
        <meta name="author" content="Codrops" />
        <link rel="shortcut icon" href="../favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
		<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
	
    </head>     
    </body>
</html> 

