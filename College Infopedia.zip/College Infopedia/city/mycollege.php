<html>
<?php
include('session_validate.php');    
?>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="home.php"><big>CourseInfoPedia</big></a>        
    </div>      
      <span style="float:right;margin-right:10px"><h4 class="btn btn-primary" onclick="window.location.href='logout.php'">LOGOUT</h4></span>
      <span style="float:right;margin-right:10px"><h4>&nbsp;</h4></span>
      <span style="float:right;margin-left:10px"><h4 class="btn btn-primary">Welcome <?php echo $_SESSION['admin'];?></h4></span>
  </div>
</nav>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="viewcollege.php">View Colleges</a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="indexclg.php" class="navbar-brand">College Information</a></li>
                <li><a href="indexplc.php" class="navbar-brand">Placememt Information</a></li>
                <li><a href="indexlib.php" class="navbar-brand">Library Information</a></li>
                <li><a href="indexoth.php" class="navbar-brand">Facilities</a></li>
            </ul>
        </div>
    </nav>    
    
    <img src="kle12.jpg">
</body>
</html>