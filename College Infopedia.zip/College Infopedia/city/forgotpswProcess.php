<?php
session_start();
    $servername = "localhost";
	$username="root";
	$password = "";
	$dbname= "crud_bootstrap";
	$email = $_POST['email'];
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error)
	{
		die("Connection failed:". $conn->connect_error);
    }
    session_start();
    $query="SELECT * from user where Email = '$email'";
    $result=mysqli_query($conn,$query);
    $count = mysqli_num_rows($result);
    if($count==1)
    {
        $_SESSION['email']= $email;
        header("location:../forgotpasswordRecovery.php");
    }
    else
    {
        echo '<script> alert("Invalid user email");</script>';
        echo '<script> window.location.assign("../forgotpassword.php");
        </script>';
    }
?>

