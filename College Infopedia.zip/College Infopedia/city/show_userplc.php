<?php
	include('conn.php');
	if(isset($_POST['show'])){
		?>
		 <h4 align="center">COLLEGE PLACEMENT DETAILS</h4> <br>
		<table class = "table table-bordered alert-warning table-hover">
			<thead>
				<th>SL No.</th>
				<th>College Name</th>
				<th>Companies Visited</th>
				<th>Students Selected</th>
				<th>Year</th>
				<th>Action</th>
			</thead>
				<tbody>
					<?php
                        $sl=1;
						$quser=mysqli_query($conn,"select * from placement,college WHERE placement.college_id=college.userid ORDER BY placement.place_id DESC ");
						while($urow=mysqli_fetch_array($quser)){
							?>
								<tr>
									<td><?php echo $sl++; ?></td>
									<td><?php echo $urow['collegename']; ?></td>
									<td><?php echo $urow['comp_visited']; ?></td>
									<td><?php echo $urow['stud_selected']; ?></td>
									<td><?php echo $urow['year']; ?></td>
									<td><button class="btn btn-success" data-toggle="modal" data-target="#edit<?php echo $urow['place_id']; ?>"><span class = "glyphicon glyphicon-pencil"></span> Edit</button> | <button class="btn btn-danger delete" value="<?php echo $urow['place_id']; ?>"><span class = "glyphicon glyphicon-trash"></span> Delete</button>
									<?php include('edit_modalplc.php'); ?>
									</td>
								</tr>
							<?php
						}
 
					?>
				</tbody>
			</table>
		<?php
	}
 
?>