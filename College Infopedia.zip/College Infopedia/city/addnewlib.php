<?php
	include('conn.php');
	if(isset($_POST['ADD']))
    {
        $college=$_POST['college'];
		$dom=$_POST['dom'];
		$nob=$_POST['nob'];
		$nom=$_POST['nom'];
		$rh=$_POST['rh'];
 
		$sql=mysqli_query($conn,"insert into `library` (college_id, Domain, no_of_books, no_of_mgzns, reading_hours) values ('$college', '$dom','$nob','$nom','$rh')");
        if($sql)
        {
            echo 'Successfully Inserted';
        }
        else
        {
            echo 'Not Inserted';
        }
	}
?>