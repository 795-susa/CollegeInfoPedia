<?php 

$servername="localhost";
$username="root";
$password="";
$dbname = "crud_bootstrap";
session_start();

$uname = $_POST['user_name'];
$pwd = $_POST['pass_word'];

$conn=new mysqli($servername,$username,$password,$dbname);

if($conn->connect_error)
{
  die("Not able to establish connection".$conn->connect_error);
}
$query="SELECT * from user where UserName = '$uname'  and Password = '$pwd'";
 $result=mysqli_query($conn,$query);
 $row=mysqli_fetch_array($result);
 $role=$row['role'];
 $username=$row['UserName'];
 $count = mysqli_num_rows($result);
 if($count==1)
 {
 	if($role=="Admin")
 	{
        $_SESSION['admin']=$username;
 		header("location:mycollege.php");
 	}
 	else
 	{
        $_SESSION['user']=$username;
        if(isset($_POST['college_id'])){
            ?>
            <script>
                window.location="../college_details.php?id=<?php echo $_POST['college_id'];?>";
            </script>  
            <?php
        }else{
            ?>
            <script>
                window.location="../index.php";
            </script>  
        <?php
        }
 		?>
 		<?php
 	}
}
else
{
 	echo '<script> alert("Invalid Username or Password");</script>';
  	echo '<script> window.location.assign("../login.php");
  </script>';
}

$conn->close();
?>