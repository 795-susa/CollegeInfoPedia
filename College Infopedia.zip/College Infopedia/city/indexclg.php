<?php
	include('conn.php');
    include('dbconnect.php');
    include('session_validate.php');
?>
<!DOCTYPE html>
<html lang = "en">
	<head>
		<meta charset = "UTF-8" name = "viewport" content = "width-device=width, initial-scale=1" />
		<link rel = "stylesheet" type = "text/css" href = "bootstrap.css" />
		<title>CourseInfoPedia</title>
	</head>
<body>

    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><big>CourseInfoPedia</big></a>        
            </div>      
            <span style="float:right;margin-right:10px"><h4 class="btn btn-primary" onclick="window.location.href='logout.php'">LOGOUT</h4></span>
            <span style="float:right;margin-right:10px"><h4>&nbsp;</h4></span>
            <span style="float:right;margin-left:10px"><h4 class="btn btn-primary">Welcome <?php echo $_SESSION['admin'];?></h4></span>
        </div>
    </nav>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="viewcollege.php">View Colleges</a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="indexclg.php" class="navbar-brand">College Information</a></li>
                <li><a href="indexplc.php" class="navbar-brand">Placememt Information</a></li>
                <li><a href="indexlib.php" class="navbar-brand">Library Information</a></li>
                <li><a href="indexoth.php" class="navbar-brand">Facilities</a></li>
            </ul>
        </div>
    </nav>    
    
<div class="container-fluid">
    <div class="col-md-16 well">
        <div class="row">        
            
            <div class="container">
               <h4 align="center">ADD NEW COLLEGE DETAILS</h4> <br>
                <form method="post" id="college_form" enctype="multipart/form-data">
                <div class="row">
                    <div class="form-group col-md-4">
                        <label for="one">CourseType</label>
                        <?php 
                        $sql="SELECT * FROM course_category";
                        $res=mysqli_query($link,$sql);                
                        ?>
                        <select name="course" id="course" class="form-control">
                            <option value="">SELECT COURSE</option>
                            <?php 
                            while($row=mysqli_fetch_array($res)){
                            ?>
                            <option value="<?php echo $row['course_id'];?>"><?php echo $row['course_name'];?></option>
                            <?php }?>
                        </select>                        

                    </div>
                    <div class="form-group col-md-4">
                        <label for="one">City</label>
                        <?php 
                        $sql="SELECT * FROM cities";
                        $res=mysqli_query($link,$sql);                
                        ?>
                        <select name="city" id="city" name='city' class="form-control">
                            <option value="">SELECT CITY</option>
                            <?php 
                            while($row=mysqli_fetch_array($res)){
                            ?>
                            <option value="<?php echo $row['city_id'];?>"><?php echo $row['city_name'];?></option>
                            <?php }?>
                        </select>                        

                    </div>
                    <div class="form-group col-md-4">
                        <label for="one">College Name</label>
                        <input type  = "text" id = "cn" name="cn" class = "form-control">
                    </div>

                    <div class="form-group col-md-4">
                        <label for="two" >Email</label>
                        <input type  = "text" id = "em" name="em" class = "form-control">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="one">Grade</label>
                        <input type  = "text" id = "gr" name="gr" class = "form-control">
                    </div>

                    <div class="form-group col-md-4">
                        <label for="two" >Address</label>
                        <input type  = "text" id = "ad" name="ad" class = "form-control">
                    </div>
                    <div class="form-group col-md-12">
                        <label for="two" >Image</label>
                        <input type  = "file" id = "img" name="img" class = "form-control">
                    </div>
                    <div class="form-group col-md-12">
                       <input type="hidden" id="ADD" name="ADD">
                        <button type="submit" id="addnew" name="addnew" class = "btn btn-primary"><span class = "glyphicon glyphicon-plus"></span> Add</button>
                    </div>
                </div>
                </form>
            </div>
        </div>        
    </div>
</div>
    
    <div class="container-fluid">
        <div class="col-md-16 well">
            <div class="row">        
                <div id="userTable"></div>
            </div>
        </div>
    </div>

</body>
<script src = "js/jquery-3.3.1.min.js"></script>	
<script src = "js/bootstrap.js"></script>
<script type = "text/javascript">
	$(document).ready(function(){
		showUser();
		//Add New
		$(document).on('submit', '#college_form', function(event) {
            event.preventDefault();
			if ($('#cn').val()=="" || $('#pf').val()=="" || $('#em').val()=="" || $('gr').val()=="" || $('#ad').val()=="" || $('#pl').val()==""){
				alert('Please input data first');
			}
			else{			
				$.ajax({
                    url: "addnewclg.php",
					method: "POST",
					data: new FormData(this),
                    contentType: false,
                    processData: false,
					success: function(data){
                        alert(data);
                        location.reload();
						showUser();
					}
				});
			}
		});
		//Delete
		$(document).on('click', '.delete', function(){
			$id=$(this).val();
				$.ajax({
					type: "POST",
					url: "deleteclg.php",
					data: {
						id: $id,
						del: 1,
					},
					success: function(data){
                        alert(data);
						showUser();
					}
				});
		});
		//Update
		$(document).on('submit', '#college_updateform', function(event) {
            event.preventDefault();
			$uid=$("#userid").val();
			$('#edit'+$uid).modal('hide');
			$('body').removeClass('modal-open');
			$('.modal-backdrop').remove();
				$.ajax({
                    url: "updateclg.php",
					method: "POST",
					data: new FormData(this),
                    contentType: false,
                    processData: false,
					success: function(data){
                        alert(data);
                        location.reload();
						showUser();
					}
				});
		});
 
	});
 
	//Showing our Table
	function showUser(){
		$.ajax({
			url: 'show_userclg.php',
			type: 'POST',
			async: false,
			data:{
				show: 1
			},
			success: function(response){
				$('#userTable').html(response);
			}
		});
	}
 
</script>

</html>