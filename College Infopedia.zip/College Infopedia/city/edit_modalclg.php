<div class="modal fade" id="edit<?php echo $urow['userid']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<?php
		$n=mysqli_query($conn,"select * from college c,course_category cc,cities ct where c.userid='".$urow['userid']."' and c.course_id=cc.course_id and c.city_id=ct.city_id ");
		$nrow=mysqli_fetch_array($n);
	?>
  <div class="modal-dialog" role="document">      
    <div class="modal-content">
		<div class = "modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" onclick="javascript:window.location.reload()">&times;</span></button>
            <center><h3 class = "text-success modal-title">UPDATE COLLEGE</h3></center>
		</div>	
		 <form method="post" id="college_updateform" enctype="multipart/form-data">	
		<div class="modal-body" >
           
            <div class="form-group">
                <label for="one">Course</label>
                <?php
                $sql1="SELECT * from course_category";
                $result1=mysqli_query($conn,$sql1);
                ?>      
                <select name="ucourse" id="ucourse" class="form-control" required="required">
                    <option value="">---SELECT COURSE---</option>
                    <?php
                    while($row1=mysqli_fetch_array($result1,MYSQLI_ASSOC)) {
                    ?>
                    <option value="<?php echo $row1['course_id'];?>" 
                            <?php 
                        if ($nrow['course_id']==$row1['course_id']) 
                        { 
                            ?>
                            selected 
                            <?php 
                        } 
                            ?>>
                        <?php echo $row1['course_name'];?></option>										
                    <?php 
                    }
                    ?>
                </select>

            </div>
            <div class="form-group">
                <label for="one">City</label>
                <?php
                $sql11="SELECT * from cities";
                $result11=mysqli_query($conn,$sql11);
                ?>      
                <select name="ucity" id="ucity" class="form-control" required="required">
                    <option value="">---SELECT CITY---</option>
                    <?php
                    while($row11=mysqli_fetch_array($result11,MYSQLI_ASSOC)) {
                    ?>
                    <option value="<?php echo $row11['city_id'];?>" 
                            <?php 
                        if ($nrow['city_id']==$row11['city_id']) 
                        { 
                            ?>
                            selected 
                            <?php 
                        } 
                            ?>>
                        <?php echo $row11['city_name'];?></option>										
                    <?php 
                    }
                    ?>
                </select>

            </div>
            <div class="form-group">
                <label for="one">College Name</label>
                <input type="text" value="<?php echo $nrow['collegename']; ?>" id="ucn" name="ucn" class="form-control">
            </div>
             <div class="form-group">
                <label for="one">College Image</label>
                <input type="file" id="uimg" name="uimg" class="form-control"><br>
                <img src="photos/<?php echo $nrow['image']; ?>" alt="<?php echo $nrow['image']; ?>" width="200" height="100">
                <input type="hidden" id="old_image" name="old_image" class="form-control" value="<?php echo $nrow['image']; ?>">
                
            </div>
            <div class="form-group">
                <label for="one">Email</label>
                <input type="text" value="<?php echo $nrow['email']; ?>" id="uem" name="uem" class="form-control">
            </div>
            <div class="form-group">
                <label for="one">Grade</label>
                <input type="text" value="<?php echo $nrow['grade']; ?>" id="ugr" name="ugr" class="form-control">
            </div>

            <div class="form-group">
                <label for="one">Address</label>
                <textarea type="text" id="uad" name="uad" class="form-control"><?php echo $nrow['address']; ?></textarea>
            </div>            
		</div>
		<input type="hidden" value="<?php echo $urow['userid']; ?>" id="userid" name="userid" class="form-control">
		<input type="hidden" value="" id="edit" name="edit" class="form-control">
		<div class="modal-footer">
			<button type="submit" class="updateuser btn btn-success" value=""><span class = "glyphicon glyphicon-floppy-disk"></span> Save</button> | <button type="button" class="btn btn-default" data-dismiss="modal" onclick="javascript:window.location.reload()"><span class = "glyphicon glyphicon-remove"></span> Cancel</button>
		</div>
        </form>
    </div>
  </div>
</div>