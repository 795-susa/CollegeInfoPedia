<html>
  <head>

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
  </head>
  <script>
function u_name()
{
	var uname1= f1.user_name.value;
	var check= /^[a-zA-Z]{3,}$/;
	if (check.test(uname1))
	{
	}
	else
	{
		alert("invalid username");
		f1.user_name.focus();
	}
}
</script>
 <nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
       
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href=""><big>CourseInfoPedia</big></a>
      </div>
     
    </div>
  </nav>

<body id="LoginForm">
<div class="container">

<div class="login-form" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
<div class="main-div">
    <div class="panel" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
  <center>
	<form name="f1" method="post" action="loginprocess.php">
		<div class="box">
			<h1>LOGIN</h1>
			Username
			<input type="text" name="user_name" class="form-control">
			<br>
			<br>
			Password
            <input type="password" name="pass_word" class="form-control">
			<br>
			<br>
			<input type="submit" class="btn btn-primary" name="login" onfocus="u_name()" onclick="main.php">
			<a id="forgot" href="forgotpsw.php" >Forgot password</a>
			</div>
		</form>
</center>
    </div>

</div></div></div>

<style>
 .navbar{
      margin: 0px;
      border-radius: 0px;
      border: 0px;
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
       
    }
   
    .navbar-default .navbar-brand{
      color: black;
    }
    .navbar-default .navbar-brand:hover{
      color: #3498DB;
    }
    .navbar-default .navbar-nav>li>a{
      color: #212F3D;
    }
    .navbar-default .navbar-nav>li>a:visited{
      color:black;
    }
    .navbar-default .navbar-nav>li>a:hover{
      background-color:#17202A;
      color:white;
    }
    .navbar-toggle{
      background-color: #5F6061;
    }
    #drop-menu:hover{
      color:black;
      background-color:  #B2B3B4;
    }

body#LoginForm{  
background-repeat:no-repeat; 
background-position:center; 
background-size:cover; padding:10px;}

.form-heading { color:#fff; font-size:23px;}
.panel h2{ color:#444444; font-size:18px; margin:0 0 8px 0;}
.panel p { color:#777777; font-size:14px; margin-bottom:30px; line-height:24px;}
.login-form .form-control {
  
  border: 1px solid #d4d4d4;
  border-radius: 4px;
  font-size: 14px;
  height: 50px;
  line-height: 50px;
}
.main-div {
  background: #ffffff none repeat scroll 0 0;
  border-radius: 2px;
  margin: 60px auto 30px;
  max-width: 45%;
  padding: 50px 70px 70px 71px;
}

.login-form .form-group {
  margin-bottom:10px;
}
.login-form{ text-align:center;}
.forgot a {
  color: #777777;
  font-size: 14px;
  text-decoration: underline;
}
.login-form  .btn.btn-primary {
  background: #f0ad4e none repeat scroll 0 0;
  border-color: #f0ad4e;
  color: #ffffff;
  font-size: 14px;
  width: 100%;
  height: 50px;
  line-height: 50px;
  padding: 0;
}
.forgot {
  text-align: left; margin-bottom:30px;
}
.botto-text {
  color: #ffffff;
  font-size: 14px;
  margin: auto;
}
.login-form .btn.btn-primary.reset {
  background: #ff9900 none repeat scroll 0 0;
}
.back { text-align: left; margin-top:10px;}
.back a {color: #444444; font-size: 13px;text-decoration: none;}

.box{
			width: 500px;
			height: 270px;
			background-color: #c6d3d2;
		}
		
.button3 {background-color: #f44336;}
		input[type=text], input[type=password] {
    width: 50%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
</style>


</body>
</html>
