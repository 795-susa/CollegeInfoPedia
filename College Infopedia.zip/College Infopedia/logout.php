<?php 
session_start();
unset($_SESSION["user"]);
session_destroy();

?>
<script>
    //alert("Logout..");
    window.location="index.php";
</script>
